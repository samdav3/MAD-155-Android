package com.example.localnotifications

class ResultActivity {
}